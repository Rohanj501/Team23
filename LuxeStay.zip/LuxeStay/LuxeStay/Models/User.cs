﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LuxeStay.Models
{
    public class User : IdentityUser<long>
    {
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress]
        [Column(TypeName = "varchar(256)")]
        public override string Email { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [Column(TypeName = "varchar(256)")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Phone Number is required")]
        [Phone]
        [Column(TypeName = "varchar(20)")]
        public override string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [Column(TypeName = "varchar(256)")]
        public override string PasswordHash { get; set; }

        [Column(TypeName = "varchar(256)")]
        public string Role { get; set; }

        public ICollection<Booking> Bookings { get; set; } = new List<Booking>();

        public override bool EmailConfirmed { get; set; } = true;
        public override bool LockoutEnabled { get; set; } = true;
        public override bool PhoneNumberConfirmed { get; set; } = true;

        public override string UserName
        {
            get => Email;
            set => Email = value;
        }

        public User()
        {
            EmailConfirmed = true;
            LockoutEnabled = true;
            PhoneNumberConfirmed = true;
        }

        public override string ToString()
        {
            return $"User{{ Id={Id}, Email='{Email}', Name='{Name}', PhoneNumber='{PhoneNumber}', Role='{Role}' }}";
        }
    }
}
