﻿
using System.ComponentModel.DataAnnotations;

namespace LuxeStay.Models
{
    internal class FutureAttribute : ValidationAttribute
    {
        public FutureAttribute()
        {
            ErrorMessage = "The date must be in the future.";
        }

        public override bool IsValid(object value)
        {
            if (value is DateTime dateTime)
            {
                return dateTime > DateTime.Now;
            }

            return false;
        }
    }
}