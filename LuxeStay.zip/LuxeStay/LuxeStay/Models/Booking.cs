﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LuxeStay.Models
{
    public class Booking
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required(ErrorMessage = "Check-in date is required")]
        public DateTime CheckInDate { get; set; }

        [Future(ErrorMessage = "Check-out date must be in the future")]
        public DateTime CheckOutDate { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Number of adults must not be less than 1")]
        public int NumOfAdults { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Number of children must not be less than 0")]
        public int NumOfChildren { get; set; }

        public int TotalNumOfGuest { get; private set; }

        public string BookingConfirmationCode { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }
        public long UserId { get; set; }

        [ForeignKey("RoomId")]
        public Room Room { get; set; }
        public long RoomId { get; set; }

        public void CalculateTotalNumberOfGuest()
        {
            TotalNumOfGuest = NumOfAdults + NumOfChildren;
        }

        public void SetNumOfAdults(int numOfAdults)
        {
            NumOfAdults = numOfAdults;
            CalculateTotalNumberOfGuest();
        }

        public void SetNumOfChildren(int numOfChildren)
        {
            NumOfChildren = numOfChildren;
            CalculateTotalNumberOfGuest();
        }

        public override string ToString()
        {
            return $"Booking{{ Id={Id}, CheckInDate={CheckInDate}, CheckOutDate={CheckOutDate}, NumOfAdults={NumOfAdults}, NumOfChildren={NumOfChildren}, TotalNumOfGuest={TotalNumOfGuest}, BookingConfirmationCode='{BookingConfirmationCode}' }}";
        }
    }
}
