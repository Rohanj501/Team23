﻿using LuxeStay.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace LuxeStay.Models
{
    public class Room
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public string RoomType { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal RoomPrice { get; set; }

        public string RoomPhotoUrl { get; set; }

        public string RoomDescription { get; set; }

        public ICollection<Booking> Bookings { get; set; } = new List<Booking>();

        public override string ToString()
        {
            return $"Room{{ Id={Id}, RoomType='{RoomType}', RoomPrice={RoomPrice}, RoomPhotoUrl='{RoomPhotoUrl}', RoomDescription='{RoomDescription}' }}";
        }
    }
}


