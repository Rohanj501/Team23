﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
namespace LuxeStay.Models.dto
{
    public class RoomDTO
    {
        public long Id { get; set; }
        public string RoomType { get; set; }
        
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public decimal? RoomPrice { get; set; }
        
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string RoomPhotoUrl { get; set; }
        
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string RoomDescription { get; set; }
        
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public List<BookingDTO> Bookings { get; set; }
    }
}

