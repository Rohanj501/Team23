﻿
using System.Collections.Generic;
using System.Text.Json.Serialization;
namespace LuxeStay.Models.dto
{
        public class UserDTO
        {
            public long Id { get; set; }
            public string Email { get; set; }
            public string Name { get; set; }
            public string PhoneNumber { get; set; }
            public string Role { get; set; }

            [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
            public List<BookingDTO> Bookings { get; set; } = new List<BookingDTO>();
        }
    }
