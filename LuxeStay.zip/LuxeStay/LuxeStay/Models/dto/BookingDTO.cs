﻿using System.Text.Json.Serialization;

namespace LuxeStay.Models.dto
{
 
    public class BookingDTO
    {
        public long Id { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public int NumOfAdults { get; set; }
        public int NumOfChildren { get; set; }
        public int TotalNumOfGuest { get; set; }
        public string BookingConfirmationCode { get; set; }
        public UserDTO User { get; set; }
        public RoomDTO Room { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public object OptionalProperty { get; set; }
    }
}
