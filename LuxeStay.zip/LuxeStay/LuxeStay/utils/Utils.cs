﻿using LuxeStay.Models;
using LuxeStay.Models.dto;

namespace LuxeStay.utils
{
    public class Utils
    {
        internal static string GenerateRandomConfirmationCode(int v)
        {
            throw new NotImplementedException();
        }

        internal static BookingDTO MapBookingEntityToBookingDTOPlusBookedRooms(Booking booking, bool v)
        {
            throw new NotImplementedException();
        }

        internal static List<BookingDTO> MapBookingListEntityToBookingListDTO(List<Booking> bookingList)
        {
            throw new NotImplementedException();
        }

        internal static RoomDTO MapRoomEntityToRoomDTO(object savedRoom)
        {
            throw new NotImplementedException();
        }

        internal static RoomDTO MapRoomEntityToRoomDTOPlusBookings(Room room)
        {
            throw new NotImplementedException();
        }

        internal static List<RoomDTO> MapRoomListEntityToRoomListDTO(List<Room> roomList)
        {
            throw new NotImplementedException();
        }

        internal static UserDTO MapUserEntityToUserDTO(User user)
        {
            throw new NotImplementedException();
        }

        internal static UserDTO MapUserEntityToUserDTOPlusUserBookingsAndRoom(object user)
        {
            throw new NotImplementedException();
        }

        internal static List<UserDTO> MapUserListEntityToUserListDTO(List<User> userList)
        {
            throw new NotImplementedException();
        }
    }
}
