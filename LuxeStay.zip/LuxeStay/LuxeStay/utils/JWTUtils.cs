﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace LuxeStay.utils
{


    namespace YourNamespace
    {
        public class JWTUtils
        {
            private const double ExpirationTimeInDays = 7; // Token expiration time in days
            private readonly SymmetricSecurityKey _key;
            private readonly string _secretKey = "843567893696976453275974432697R634976R738467TR678T34865R6834R8763T478378637664538745673865783678548735687R3";

            public JWTUtils()
            {
                var keyBytes = Encoding.UTF8.GetBytes(_secretKey);
                _key = new SymmetricSecurityKey(keyBytes);
            }

            public string GenerateToken(ClaimsIdentity claimsIdentity)
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = claimsIdentity,
                    Expires = DateTime.UtcNow.AddDays(ExpirationTimeInDays),
                    SigningCredentials = new SigningCredentials(_key, SecurityAlgorithms.HmacSha256)
                };

                var token = tokenHandler.CreateToken(tokenDescriptor);
                return tokenHandler.WriteToken(token);
            }

            public string ExtractUsername(string token)
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadToken(token) as JwtSecurityToken;
                return jwtToken?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;
            }

            public bool IsValidToken(string token, ClaimsIdentity claimsIdentity)
            {
                var username = ExtractUsername(token);
                return username == claimsIdentity.Name && !IsTokenExpired(token);
            }

            private bool IsTokenExpired(string token)
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadToken(token) as JwtSecurityToken;
                return jwtToken?.ValidTo < DateTime.UtcNow;
            }
        }
    }
}
