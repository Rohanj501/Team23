﻿using LuxeStay.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace LuxeStay.data
{
    namespace LuxeStay
    {
        public class ApplicationDbContext : DbContext 
        {
            public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
                : base(options)
            {
            }

            public DbSet<Booking> Bookings { get; set; }
            public DbSet<Room> Rooms { get; set; }

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                base.OnModelCreating(modelBuilder);

                // Configure relationships and any additional configurations here

                modelBuilder.Entity<User>(entity =>
                {
                    entity.ToTable(name: "Users");
                });

                modelBuilder.Entity<Booking>(entity =>
                {
                    entity.ToTable(name: "Bookings");
                    entity.HasOne(b => b.User)
                          .WithMany(u => u.Bookings)
                          .HasForeignKey(b => b.UserId);
                    entity.HasOne(b => b.Room)
                          .WithMany(r => r.Bookings)
                          .HasForeignKey(b => b.RoomId);
                });

                modelBuilder.Entity<Room>(entity =>
                {
                    entity.ToTable(name: "Rooms");
                });
            }
        }
    }
}
