﻿using LuxeStay.exception;
using LuxeStay.Models;
using LuxeStay.Models.dto;
using LuxeStay.repo;
using LuxeStay.utils;
using Microsoft.AspNetCore.Identity;

namespace LuxeStay.service.impl
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IJwtUtils _jwtUtils;
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;

        public UserService(
            IUserRepository userRepository,
            IJwtUtils jwtUtils,
            UserManager<User> userManager,
            SignInManager<User> signInManager)
        {
            _userRepository = userRepository;
            _jwtUtils = jwtUtils;
            _userManager = userManager;
            _signInManager = signInManager;
        }

        public async Task<Response> RegisterAsync(User user)
        {
            var response = new Response();

            try
            {
                if (string.IsNullOrWhiteSpace(user.Role))
                {
                    user.Role = "USER";
                }

                if (await _userRepository.ExistsByEmailAsync(user.Email))
                {
                    throw new OurException($"{user.Email} Already Exists");
                }

                user.PasswordHash = _userManager.PasswordHasher.HashPassword(user, user.PasswordHash);
                var result = await _userManager.CreateAsync(user);

                if (!result.Succeeded)
                {
                    throw new Exception(string.Join(", ", result.Errors));
                }

                var userDTO = Utils.MapUserEntityToUserDTO(user);
                response.StatusCode = 200;
                response.User = userDTO;
            }
            catch (OurException e)
            {
                response.StatusCode = 400;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error Occurred During User Registration: {e.Message}";
            }

            return response;
        }

        public async Task<Response> LoginAsync(LoginRequest loginRequest)
        {
            var response = new Response();

            try
            {
                var result = await _signInManager.PasswordSignInAsync(loginRequest.Email, loginRequest.Password, isPersistent: false, lockoutOnFailure: false);

                if (!result.Succeeded)
                {
                    throw new OurException("Invalid credentials");
                }

                var user = await _userRepository.FindByEmailAsync(loginRequest.Email) ?? throw new OurException("User Not Found");
                var token = _jwtUtils.GenerateToken(user);

                response.StatusCode = 200;
                response.Token = token;
                response.Role = user.Role;
                response.ExpirationTime = "7 Days";
                response.Message = "successful";
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error Occurred During User Login: {e.Message}";
            }

            return response;
        }

        public async Task<Response> GetAllUsersAsync()
        {
            var response = new Response();

            try
            {
                // Fetch all users from the repository
                var userList = await _userRepository.GetAllAsync();

                // Map the list of user entities to a list of user DTOs
                var userDTOList = Utils.MapUserListEntityToUserListDTO(userList);

                // Set the response status and message for a successful operation
                response.StatusCode = 200;
                response.Message = "successful";
                response.UserList = userDTOList;
            }
            catch (Exception e)
            {
                // Set the response status and message for an error
                response.StatusCode = 500;
                response.Message = $"Error getting all users: {e.Message}";
            }

            return response;
        }


        public async Task<Response> GetUserBookingHistoryAsync(string userId)
        {
            var response = new Response();

            try
            {
                var user = await _userRepository.FindByIdAsync(long.Parse(userId)) ?? throw new OurException("User Not Found");
                var userDTO = Utils.MapUserEntityToUserDTOPlusUserBookingsAndRoom(user);

                response.StatusCode = 200;
                response.Message = "successful";
                response.User = userDTO;
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error getting user booking history: {e.Message}";
            }

            return response;
        }

        public async Task<Response> DeleteUserAsync(string userId)
        {
            var response = new Response();

            try
            {
                var id = long.Parse(userId);
                var user = await _userRepository.FindByIdAsync(id) ?? throw new OurException("User Not Found");
                await _userRepository.DeleteAsync(id);

                response.StatusCode = 200;
                response.Message = "successful";
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error deleting user: {e.Message}";
            }

            return response;
        }

        public async Task<Response> GetUserByIdAsync(string userId)
        {
            var response = new Response();

            try
            {
                var user = await _userRepository.FindByIdAsync(long.Parse(userId)) ?? throw new OurException("User Not Found");
                var userDTO = Utils.MapUserEntityToUserDTO(user);

                response.StatusCode = 200;
                response.Message = "successful";
                response.User = userDTO;
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error getting user by ID: {e.Message}";
            }

            return response;
        }

        public async Task<Response> GetMyInfoAsync(string email)
        {
            var response = new Response();

            try
            {
                var user = await _userRepository.FindByEmailAsync(email) ?? throw new OurException("User Not Found");
                var userDTO = Utils.MapUserEntityToUserDTO(user);

                response.StatusCode = 200;
                response.Message = "successful";
                response.User = userDTO;
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error getting user info: {e.Message}";
            }

            return response;
        }
    }
}
