﻿using LuxeStay.Models;

namespace LuxeStay.service.impl
{
    public interface IJwtUtils
    {
        string GenerateToken(User user);
    }
}