﻿
namespace LuxeStay.service.impl
{
    public interface IAwsS3Service
    {
        Task<string?> SaveImageToS3Async(IFormFile photo);
    }
}