﻿using LuxeStay.exception;
using LuxeStay.Models;
using LuxeStay.Models.dto;
using LuxeStay.repo;
using LuxeStay.Repo;
using LuxeStay.Repo.MyProject.Repositories.Interfaces;
using LuxeStay.Service.Internal;
using LuxeStay.utils;


namespace LuxeStay.Service.Impl
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository _bookingRepository;
        private readonly IRoomRepository _roomRepository;
        private readonly IUserRepository _userRepository;

        public BookingService(
            IBookingRepository bookingRepository,
            IRoomRepository roomRepository,
            IUserRepository userRepository)
        {
            _bookingRepository = bookingRepository;
            _roomRepository = roomRepository;
            _userRepository = userRepository;
        }

        public async Task<Response> SaveBookingAsync(long roomId, long userId, Booking bookingRequest)
        {
            var response = new Response();

            try
            {
                if (bookingRequest.CheckOutDate < bookingRequest.CheckInDate)
                {
                    throw new ArgumentException("Check-in date must be before check-out date");
                }

                var room = await _roomRepository.FindByIdAsync(roomId) ?? throw new OurException("Room Not Found");
                var user = await _userRepository.FindByIdAsync(userId) ?? throw new OurException("User Not Found");

                var existingBookings = await _bookingRepository.GetAllAsync(); // Fetch all bookings to check availability

                if (!RoomIsAvailable(bookingRequest, existingBookings))
                {
                    throw new OurException("Room not available for the selected date range");
                }

                bookingRequest.Room = room;
                bookingRequest.User = user;
                bookingRequest.BookingConfirmationCode = Utils.GenerateRandomConfirmationCode(10);
                await _bookingRepository.AddAsync(bookingRequest);

                response.StatusCode = 200;
                response.Message = "Successful";
                response.BookingConfirmationCode = bookingRequest.BookingConfirmationCode;
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error saving booking: {e.Message}";
            }

            return response;
        }

        public async Task<Response> FindBookingByConfirmationCodeAsync(string confirmationCode)
        {
            var response = new Response();

            try
            {
                var booking = await _bookingRepository.FindByBookingConfirmationCodeAsync(confirmationCode)
                    ?? throw new OurException("Booking Not Found");

                var bookingDTO = Utils.MapBookingEntityToBookingDTOPlusBookedRooms(booking, true);

                response.StatusCode = 200;
                response.Message = "Successful";
                response.Booking = bookingDTO;
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error finding booking: {e.Message}";
            }

            return response;
        }

        public async Task<Response> GetAllBookingsAsync()
        {
            var response = new Response();

            try
            {
                var bookingList = await _bookingRepository.GetAllAsync();
                var bookingDTOList = Utils.MapBookingListEntityToBookingListDTO(bookingList);

                response.StatusCode = 200;
                response.Message = "Successful";
                response.BookingList = bookingDTOList;
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error getting all bookings: {e.Message}";
            }

            return response;
        }

        public async Task<Response> CancelBookingAsync(long bookingId)
        {
            var response = new Response();

            try
            {
                await _bookingRepository.DeleteAsync(bookingId);
                response.StatusCode = 200;
                response.Message = "Successful";
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error cancelling booking: {e.Message}";
            }

            return response;
        }

        private bool RoomIsAvailable(Booking bookingRequest, List<Booking> existingBookings)
        {
            return !existingBookings.Any(existingBooking =>
                bookingRequest.CheckInDate < existingBooking.CheckOutDate &&
                bookingRequest.CheckOutDate > existingBooking.CheckInDate
            );
        }
    }
}
