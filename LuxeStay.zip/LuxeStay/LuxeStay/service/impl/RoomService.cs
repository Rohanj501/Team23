﻿using LuxeStay.exception;

using LuxeStay.Models;
using LuxeStay.Models.dto;

using LuxeStay.Repo;
using LuxeStay.Repo.MyProject.Repositories.Interfaces;
using LuxeStay.service.impl;
using LuxeStay.Service.Internal;
using LuxeStay.utils;



namespace LuxeStay.Service.Impl
{
    public class RoomService : IRoomService
    {
        private readonly IRoomRepository _roomRepository;
        private readonly IBookingRepository _bookingRepository;
        private readonly IAwsS3Service _awsS3Service;

        public RoomService(
            IRoomRepository roomRepository,
            IBookingRepository bookingRepository,
            IAwsS3Service awsS3Service)
        {
            _roomRepository = roomRepository;
            _bookingRepository = bookingRepository;
            _awsS3Service = awsS3Service;
        }

        public async Task<Response> AddNewRoomAsync(IFormFile photo, string roomType, decimal roomPrice, string description)
        {
            var response = new Response();

            try
            {
                // Validate input parameters
                if (photo == null || photo.Length == 0)
                {
                    throw new ArgumentException("Invalid photo.");
                }

                if (string.IsNullOrEmpty(roomType))
                {
                    throw new ArgumentException("Room type cannot be empty.");
                }

                if (roomPrice <= 0)
                {
                    throw new ArgumentException("Room price must be greater than zero.");
                }

                // Save image to S3
                var imageUrl = await _awsS3Service.SaveImageToS3Async(photo);

                // Create room object
                var room = new Room
                {
                    RoomPhotoUrl = imageUrl,
                    RoomType = roomType,
                    RoomPrice = roomPrice,
                    RoomDescription = description
                };

                // Save room to repository
                var savedRoom = await _roomRepository.AddAsync(room);

                // Map saved room to DTO
                var roomDTO = Utils.MapRoomEntityToRoomDTO(savedRoom);

                // Prepare response
                response.StatusCode = 200;
                response.Message = "Room successfully added.";
                response.Room = roomDTO;
            }
            catch (ArgumentException ex)
            {
                response.StatusCode = 400; // Bad Request
                response.Message = ex.Message;
            }
            catch (Exception ex)
            {
                response.StatusCode = 500; // Internal Server Error
                response.Message = $"Error saving room: {ex.Message}";
            }

            return response;
        }


        public async Task<List<string>> GetAllRoomTypesAsync()
        {
            return await _roomRepository.FindDistinctRoomTypesAsync();
        }

        public async Task<Response> GetAllRoomsAsync()
        {
            var response = new Response();

            try
            {
                var roomList = await _roomRepository.GetAllAsync();
                var roomDTOList = Utils.MapRoomListEntityToRoomListDTO(roomList);

                response.StatusCode = 200;
                response.Message = "Successful";
                response.RoomList = roomDTOList;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error getting all rooms: {e.Message}";
            }

            return response;
        }

        public async Task<Response> DeleteRoomAsync(long roomId)
        {
            var response = new Response();

            try
            {
                var room = await _roomRepository.FindByIdAsync(roomId);
                if (room == null)
                {
                    throw new OurException("Room Not Found");
                }

                // DeleteAsync does not return any value, so no need to assign it to a variable
                await _roomRepository.DeleteAsync(roomId);

                response.StatusCode = 200;
                response.Message = "Successful";
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error deleting room: {e.Message}";
            }

            return response;
        }


        public async Task<Response> UpdateRoomAsync(long roomId, string description, string roomType, decimal roomPrice, IFormFile photo)
        {
            var response = new Response();

            try
            {
                // Find the room by ID
                var room = await _roomRepository.FindByIdAsync(roomId);
                if (room == null)
                {
                    throw new OurException("Room Not Found");
                }

                string imageUrl = null;
                // Save new image to S3 if provided
                if (photo != null && photo.Length > 0)
                {
                    imageUrl = await _awsS3Service.SaveImageToS3Async(photo);
                }

                // Update room details
                if (!string.IsNullOrEmpty(roomType)) room.RoomType = roomType;
                if (roomPrice > 0) room.RoomPrice = roomPrice;
                if (!string.IsNullOrEmpty(description)) room.RoomDescription = description;
                if (!string.IsNullOrEmpty(imageUrl)) room.RoomPhotoUrl = imageUrl;

                // Update the room in the repository
                await _roomRepository.UpdateAsync(room);

                // Map updated room to DTO
                var roomDTO = Utils.MapRoomEntityToRoomDTO(room);

                // Prepare the response
                response.StatusCode = 200;
                response.Message = "Successful";
                response.Room = roomDTO;
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error updating room: {e.Message}";
            }

            return response;
        }


        public async Task<Response> GetRoomByIdAsync(long roomId)
        {
            var response = new Response();

            try
            {
                var room = await _roomRepository.FindByIdAsync(roomId);
                if (room == null)
                {
                    throw new OurException("Room Not Found");
                }

                var roomDTO = Utils.MapRoomEntityToRoomDTOPlusBookings(room);
                response.StatusCode = 200;
                response.Message = "Successful";
                response.Room = roomDTO;
            }
            catch (OurException e)
            {
                response.StatusCode = 404;
                response.Message = e.Message;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error getting room: {e.Message}";
            }

            return response;
        }

        public async Task<Response> GetAvailableRoomsByDateAndTypeAsync(DateTime checkInDate, DateTime checkOutDate, string roomType)
        {
            var response = new Response();

            try
            {
                var availableRooms = await _roomRepository.FindAvailableRoomsByDatesAndTypesAsync(checkInDate, checkOutDate, roomType);
                var roomDTOList = Utils.MapRoomListEntityToRoomListDTO(availableRooms);

                response.StatusCode = 200;
                response.Message = "Successful";
                response.RoomList = roomDTOList;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error getting available rooms: {e.Message}";
            }

            return response;
        }

        public async Task<Response> GetAllAvailableRoomsAsync()
        {
            var response = new Response();

            try
            {
                var roomList = await _roomRepository.GetAllAvailableRoomsAsync();
                var roomDTOList = Utils.MapRoomListEntityToRoomListDTO(roomList);

                response.StatusCode = 200;
                response.Message = "Successful";
                response.RoomList = roomDTOList;
            }
            catch (Exception e)
            {
                response.StatusCode = 500;
                response.Message = $"Error getting available rooms: {e.Message}";
            }

            return response;
        }

        public Task UpdateRoomAsync(long roomId, string roomDescription, string roomType, decimal? roomPrice, IFormFile photo)
        {
            throw new NotImplementedException();
        }

        Task<Response> IRoomService.UpdateRoomAsync(long roomId, string description, string roomType, decimal? roomPrice, IFormFile photo)
        {
            throw new NotImplementedException();
        }
    }
}
