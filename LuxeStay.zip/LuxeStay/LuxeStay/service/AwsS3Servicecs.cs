﻿using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace LuxeStay.service
{
    public class AwsS3Service
    {
        private readonly string _bucketName;
        private readonly IAmazonS3 _s3Client;

        public AwsS3Service(IConfiguration configuration)
        {
            _bucketName = configuration["AWS:S3:BucketName"];
            var awsAccessKey = configuration["AWS:S3:AccessKey"];
            var awsSecretKey = configuration["AWS:S3:SecretKey"];

            var awsCredentials = new Amazon.Runtime.BasicAWSCredentials(awsAccessKey, awsSecretKey);
            _s3Client = new AmazonS3Client(awsCredentials, Amazon.RegionEndpoint.USEast2);
        }

        public async Task<string> SaveImageToS3Async(Stream fileStream, string fileName, string contentType)
        {
            try
            {
                var transferUtility = new TransferUtility(_s3Client);
                var uploadRequest = new TransferUtilityUploadRequest
                {
                    InputStream = fileStream,
                    Key = fileName,
                    BucketName = _bucketName,
                    ContentType = contentType
                };

                await transferUtility.UploadAsync(uploadRequest);
                return $"https://{_bucketName}.s3.amazonaws.com/{fileName}";
            }
            catch (Exception e)
            {
                throw new Exception($"Unable to upload image to S3 bucket: {e.Message}", e);
            }
        }

        public async Task<string> SaveImageToS3Async(IFormFile photo)
        {
            if (photo == null || photo.Length == 0)
            {
                throw new ArgumentException("Invalid photo.");
            }

            using var fileStream = photo.OpenReadStream();
            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(photo.FileName);
            var contentType = photo.ContentType;

            return await SaveImageToS3Async(fileStream, fileName, contentType);
        }
    }
}
