﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using LuxeStay.Models.dto;

namespace LuxeStay.Service.Internal
{
    public interface IRoomService
    {
        Task<Response> AddNewRoomAsync(IFormFile photo, string roomType, decimal roomPrice, string description);

        Task<List<string>> GetAllRoomTypesAsync();

        Task<Response> GetAllRoomsAsync();

        Task<Response> DeleteRoomAsync(long roomId);

        Task<Response> UpdateRoomAsync(long roomId, string description, string roomType, decimal? roomPrice, IFormFile photo);

        Task<Response> GetRoomByIdAsync(long roomId);

        Task<Response> GetAvailableRoomsByDateAndTypeAsync(DateTime checkInDate, DateTime checkOutDate, string roomType);

        Task<Response> GetAllAvailableRoomsAsync();
    }
}
