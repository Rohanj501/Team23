﻿using LuxeStay.Models;
using LuxeStay.Models.dto;

public interface IUserService
    {
        Task<Response> RegisterAsync(User user);

        Task<Response> LoginAsync(LoginRequest loginRequest);

        Task<Response> GetAllUsersAsync();

        Task<Response> GetUserBookingHistoryAsync(string userId);

        Task<Response> DeleteUserAsync(string userId);

        Task<Response> GetUserByIdAsync(string userId);

        Task<Response> GetMyInfoAsync(string email);
    }

