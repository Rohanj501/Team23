﻿using LuxeStay.Models;
using LuxeStay.Models.dto;
namespace LuxeStay.Service.Internal
{

    public interface IBookingService
    {
        Task<Response> SaveBookingAsync(long roomId, long userId, Booking bookingRequest);

        Task<Response> FindBookingByConfirmationCodeAsync(string confirmationCode);

        Task<Response> GetAllBookingsAsync();

        Task<Response> CancelBookingAsync(long bookingId);
    }
}

