﻿using LuxeStay.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LuxeStay.Repo
{
    public interface IRoomRepository
    {
        Task<List<string>> FindDistinctRoomTypesAsync();
        Task<List<Room>> FindAvailableRoomsByDatesAndTypesAsync(DateTime checkInDate, DateTime checkOutDate, string roomType);
        Task<List<Room>> GetAllAvailableRoomsAsync();
        Task<Room> FindByIdAsync(long id);
        Task<Room> AddAsync(Room room);

        Task UpdateAsync(Room room);
        Task DeleteAsync(long id);
        Task<List<Room>> GetAllAsync();
    }
}
