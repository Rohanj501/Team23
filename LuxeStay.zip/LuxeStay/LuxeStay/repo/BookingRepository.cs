﻿using LuxeStay.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LuxeStay.Repo.MyProject.Repositories.Interfaces
{
    public interface IBookingRepository
    {
        Task<Booking> FindByIdAsync(long id);
        Task<Booking> FindByBookingConfirmationCodeAsync(string confirmationCode);
        Task AddAsync(Booking booking);
        Task UpdateAsync(Booking booking);
        Task DeleteAsync(long id);
        Task<List<Booking>> GetAllAsync();
    }
}
