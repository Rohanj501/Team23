﻿using LuxeStay.Models;

namespace LuxeStay.repo
{
        public interface IUserRepository
        {
            Task<bool> ExistsByEmailAsync(string email);
            Task<User> FindByEmailAsync(string email);
            Task<User> FindByIdAsync(long id);
            Task AddAsync(User user);
            Task UpdateAsync(User user);
            Task DeleteAsync(long id);
            Task<List<User>> GetAllAsync();
        }
    }
