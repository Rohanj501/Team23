﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Threading.Tasks;
using LuxeStay.Models.dto;

namespace LuxeStay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet("all")]
        [Authorize(Roles = "ADMIN")]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                var response = await _userService.GetAllUsersAsync();
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error fetching all users: {ex.Message}"
                });
            }
        }

        [HttpGet("get-by-id/{userId}")]
        public async Task<IActionResult> GetUserById(string userId)
        {
            try
            {
                var response = await _userService.GetUserByIdAsync(userId);
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error fetching user by ID: {ex.Message}"
                });
            }
        }

        [HttpDelete("delete/{userId}")]
        [Authorize(Roles = "ADMIN")]
        public async Task<IActionResult> DeleteUser(string userId)
        {
            try
            {
                var response = await _userService.DeleteUserAsync(userId);
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error deleting user: {ex.Message}"
                });
            }
        }

        [HttpGet("get-logged-in-profile-info")]
        public async Task<IActionResult> GetLoggedInUserProfile()
        {
            try
            {
                var email = User.FindFirst(ClaimTypes.Name)?.Value;
                if (string.IsNullOrEmpty(email))
                {
                    return Unauthorized(new Response
                    {
                        StatusCode = 401,
                        Message = "User not authenticated"
                    });
                }

                var response = await _userService.GetMyInfoAsync(email);
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error fetching logged-in user profile: {ex.Message}"
                });
            }
        }

        [HttpGet("get-user-bookings/{userId}")]
        public async Task<IActionResult> GetUserBookingHistory(string userId)
        {
            try
            {
                var response = await _userService.GetUserBookingHistoryAsync(userId);
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error fetching user booking history: {ex.Message}"
                });
            }
        }
    }
}
