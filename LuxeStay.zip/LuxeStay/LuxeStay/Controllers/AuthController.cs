﻿using LuxeStay.Models;
using LuxeStay.Models.dto;
using LuxeStay.service; // Adjust namespace based on your actual service location
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace LuxeStay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserService _userService;

        public AuthController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            var response = await _userService.RegisterAsync(user);
            return StatusCode(response.StatusCode, response);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest loginRequest)
        {
            var response = await _userService.LoginAsync(loginRequest);
            return StatusCode(response.StatusCode, response);
        }
    }
}
