﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using LuxeStay.Models;
using LuxeStay.Service.Internal;

namespace LuxeStay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly IBookingService _bookingService;

        public BookingController(IBookingService bookingService)
        {
            _bookingService = bookingService;
        }

        [HttpPost("book-room/{roomId}/{userId}")]
        [Authorize(Roles = "ADMIN,USER")]
        public async Task<IActionResult> SaveBookings(long roomId, long userId, [FromBody] Booking bookingRequest)
        {
            var response = await _bookingService.SaveBookingAsync(roomId, userId, bookingRequest);
            return StatusCode(response.StatusCode, response);
        }

        [HttpGet("all")]
        [Authorize(Roles = "ADMIN")]
        public async Task<IActionResult> GetAllBookings()
        {
            var response = await _bookingService.GetAllBookingsAsync();
            return StatusCode(response.StatusCode, response);
        }

        [HttpGet("get-by-confirmation-code/{confirmationCode}")]
        public async Task<IActionResult> GetBookingByConfirmationCode(string confirmationCode)
        {
            var response = await _bookingService.FindBookingByConfirmationCodeAsync(confirmationCode);
            return StatusCode(response.StatusCode, response);
        }

        [HttpDelete("cancel/{bookingId}")]
        [Authorize(Roles = "ADMIN,USER")]
        public async Task<IActionResult> CancelBooking(long bookingId)
        {
            var response = await _bookingService.CancelBookingAsync(bookingId);
            return StatusCode(response.StatusCode, response);
        }
    }
}
