﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using LuxeStay.Models.dto;
using LuxeStay.Service.Internal;

namespace LuxeStay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomController : ControllerBase
    {
        private readonly IRoomService _roomService;
        private readonly IBookingService _bookingService;

        public RoomController(IRoomService roomService, IBookingService bookingService)
        {
            _roomService = roomService;
            _bookingService = bookingService;
        }

        [HttpPost("add")]
        [Authorize(Roles = "ADMIN")]
        public async Task<IActionResult> AddNewRoom(
            [FromForm] IFormFile photo,
            [FromForm] string roomType,
            [FromForm] decimal? roomPrice,
            [FromForm] string roomDescription)
        {
            if (photo == null || string.IsNullOrWhiteSpace(roomType) || roomPrice == null)
            {
                return BadRequest(new Response
                {
                    StatusCode = 400,
                    Message = "Please provide values for all fields (photo, roomType, roomPrice)"
                });
            }

            try
            {
                var response = await _roomService.AddNewRoomAsync(photo, roomType, roomPrice.Value, roomDescription);
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error adding room: {ex.Message}"
                });
            }
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAllRooms()
        {
            try
            {
                var response = await _roomService.GetAllRoomsAsync();
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error fetching rooms: {ex.Message}"
                });
            }
        }

        [HttpGet("types")]
        public IActionResult GetRoomTypes()
        {
            try
            {
                var roomTypes = _roomService.GetAllRoomTypesAsync();
                return Ok(roomTypes);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error fetching room types: {ex.Message}"
                });
            }
        }

        [HttpGet("room-by-id/{roomId}")]
        public async Task<IActionResult> GetRoomById(long roomId)
        {
            try
            {
                var response = await _roomService.GetRoomByIdAsync(roomId);
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error fetching room by ID: {ex.Message}"
                });
            }
        }

        [HttpGet("all-available-rooms")]
        public async Task<IActionResult> GetAvailableRooms()
        {
            try
            {
                var response = await _roomService.GetAllAvailableRoomsAsync();
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error fetching available rooms: {ex.Message}"
                });
            }
        }

        [HttpGet("available-rooms-by-date-and-type")]
        public async Task<IActionResult> GetAvailableRoomsByDateAndType(
            [FromQuery] DateTime? checkInDate,
            [FromQuery] DateTime? checkOutDate,
            [FromQuery] string roomType)
        {
            if (checkInDate == null || checkOutDate == null || string.IsNullOrWhiteSpace(roomType))
            {
                return BadRequest(new Response
                {
                    StatusCode = 400,
                    Message = "Please provide values for all fields (checkInDate, checkOutDate, roomType)"
                });
            }

            try
            {
                var response = await _roomService.GetAvailableRoomsByDateAndTypeAsync(checkInDate.Value, checkOutDate.Value, roomType);
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error fetching available rooms by date and type: {ex.Message}"
                });
            }
        }

        [HttpPut("update/{roomId}")]
        [Authorize(Roles = "ADMIN")]
        public async Task<IActionResult> UpdateRoom(long roomId,
                                                    [FromForm] IFormFile photo,
                                                    [FromForm] string roomType,
                                                    [FromForm] decimal? roomPrice,
                                                    [FromForm] string roomDescription)
        {
            try
            {
                var response = await _roomService.UpdateRoomAsync(roomId, roomDescription, roomType, roomPrice, photo);
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error updating room: {ex.Message}"
                });
            }
        }

        [HttpDelete("delete/{roomId}")]
        [Authorize(Roles = "ADMIN")]
        public async Task<IActionResult> DeleteRoom(long roomId)
        {
            try
            {
                var response = await _roomService.DeleteRoomAsync(roomId);
                return StatusCode(response.StatusCode, response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new Response
                {
                    StatusCode = 500,
                    Message = $"Error deleting room: {ex.Message}"
                });
            }
        }
    }
}
