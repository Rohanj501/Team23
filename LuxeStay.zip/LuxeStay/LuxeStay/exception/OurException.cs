﻿namespace LuxeStay.exception
{
        public class OurException : Exception
        {
            public OurException(string message) : base(message)
            {
            }
        }
    }
