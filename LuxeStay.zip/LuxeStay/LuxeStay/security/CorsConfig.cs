﻿namespace LuxeStay.security
{
    public class CorsConfig
    {
    }
}
