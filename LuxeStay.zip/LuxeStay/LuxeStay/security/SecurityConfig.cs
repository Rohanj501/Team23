﻿namespace LuxeStay.security
{
    public class SecurityConfig
    {
    }
}
