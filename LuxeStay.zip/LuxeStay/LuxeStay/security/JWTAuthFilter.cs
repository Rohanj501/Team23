﻿namespace LuxeStay.security
{
    public class JWTAuthFilter
    {
    }
}
