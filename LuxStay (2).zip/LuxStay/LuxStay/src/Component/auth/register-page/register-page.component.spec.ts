import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../service/api.service';

@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.component.html',
  styleUrls: ['./register-page.component.css']
})
export class RegisterPageComponent {
  formData = {
    name: '',
    email: '',
    password: '',
    phoneNumber: ''
  };

  errorMessage = '';
  successMessage = '';

  constructor(private apiService: ApiService, private router: Router) {}

  handleInputChange(event: Event) {
    const target = event.target as HTMLInputElement;
    const { name, value } = target;
    this.formData = { ...this.formData, [name]: value };
  }

  validateForm(): boolean {
    const { name, email, password, phoneNumber } = this.formData;
    return !!name && !!email && !!password && !!phoneNumber;
  }

  async handleSubmit(): Promise<void> {
    if (!this.validateForm()) {
      this.errorMessage = 'Please fill all the fields.';
      setTimeout(() => (this.errorMessage = ''), 5000);
      return;
    }

    try {
      const response: any = await this.apiService.registerUser(this.formData);
      if (response.statusCode === 200) {
        this.formData = {
          name: '',
          email: '',
          password: '',
          phoneNumber: ''
        };
        this.successMessage = 'User registered successfully';
        setTimeout(() => {
          this.successMessage = '';
          this.router.navigate(['/']);
        }, 3000);
      }
    } catch (error: any) {
      this.errorMessage = error.error?.message || error.message;
      setTimeout(() => (this.errorMessage = ''), 5000);
    }
  }
}
