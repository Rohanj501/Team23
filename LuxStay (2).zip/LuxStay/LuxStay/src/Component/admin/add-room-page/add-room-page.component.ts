import { Component } from '@angular/core';

@Component({
  selector: 'app-add-room-page',
  standalone: true,
  imports: [],
  templateUrl: './add-room-page.component.html',
  styleUrl: './add-room-page.component.css'
})
export class AddRoomPageComponent {

}
