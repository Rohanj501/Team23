import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../service/api.service';

@Component({
  selector: 'app-manage-room',
  templateUrl: './manage-room.component.html',
  styleUrls: ['./manage-room.component.css']
})
export class ManageRoomComponent implements OnInit {
  rooms: any[] = [];
  filteredRooms: any[] = [];
  roomTypes: string[] = [];
  selectedRoomType: string = '';
  currentPage: number = 1;
  roomsPerPage: number = 5;

  constructor(private apiService: ApiService, private router: Router) {}

  ngOnInit(): void {
    this.fetchRooms();
    this.fetchRoomTypes();
  }

  fetchRooms(): void {
    this.apiService.getAllRooms().subscribe(
      (response: any) => {
        this.rooms = response.roomList;
        this.filteredRooms = this.rooms;
      },
      (error) => {
        console.error('Error fetching rooms:', error.message);
      }
    );
  }

  fetchRoomTypes(): void {
    this.apiService.getRoomTypes().subscribe(
      (types: string[]) => {
        this.roomTypes = types;
      },
      (error) => {
        console.error('Error fetching room types:', error.message);
      }
    );
  }

  handleRoomTypeChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    this.selectedRoomType = target.value;
    this.filterRooms(this.selectedRoomType);
  }

  filterRooms(type: string): void {
    if (type === '') {
      this.filteredRooms = this.rooms;
    } else {
      this.filteredRooms = this.rooms.filter((room) => room.roomType === type);
    }
    this.currentPage = 1; // Reset to first page after filtering
  }

  paginate(pageNumber: number): void {
    this.currentPage = pageNumber;
  }

  navigateToAddRoom(): void {
    this.router.navigate(['/admin/add-room']);
  }

  get currentRooms(): any[] {
    const indexOfLastRoom = this.currentPage * this.roomsPerPage;
    const indexOfFirstRoom = indexOfLastRoom - this.roomsPerPage;
    return this.filteredRooms.slice(indexOfFirstRoom, indexOfLastRoom);
  }
}
