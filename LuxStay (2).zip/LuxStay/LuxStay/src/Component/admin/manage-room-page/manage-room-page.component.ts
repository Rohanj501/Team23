import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-room-page',
  standalone: true,
  imports: [],
  templateUrl: './manage-room-page.component.html',
  styleUrl: './manage-room-page.component.css'
})
export class ManageRoomPageComponent {

}
