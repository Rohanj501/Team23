import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-room-page',
  standalone: true,
  imports: [],
  templateUrl: './edit-room-page.component.html',
  styleUrl: './edit-room-page.component.css'
})
export class EditRoomPageComponent {

}
