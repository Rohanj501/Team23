import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../../service/api.service';

@Component({
  selector: 'app-edit-room',
  templateUrl: './edit-room.component.html',
  styleUrls: ['./edit-room.component.css']
})
export class EditRoomComponent implements OnInit {
  roomId: string;
  roomDetails = {
    roomPhotoUrl: '',
    roomType: '',
    roomPrice: '',
    roomDescription: ''
  };
  file: File | null = null;
  preview: string | null = null;
  error: string = '';
  success: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiService: ApiService
  ) {
    this.roomId = this.route.snapshot.paramMap.get('roomId')!;
  }

  ngOnInit(): void {
    this.fetchRoomDetails();
  }

  fetchRoomDetails(): void {
    this.apiService.getRoomById(this.roomId).subscribe(
      (response: any) => {
        this.roomDetails = {
          roomPhotoUrl: response.room.roomPhotoUrl,
          roomType: response.room.roomType,
          roomPrice: response.room.roomPrice,
          roomDescription: response.room.roomDescription
        };
      },
      (error) => {
        this.error = error.error?.message || error.message;
      }
    );
  }

  handleChange(e: Event): void {
    const target = e.target as HTMLInputElement;
    const { name, value } = target;
    this.roomDetails = { ...this.roomDetails, [name]: value };
  }

  handleFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] || null;
    if (file) {
      this.file = file;
      this.preview = URL.createObjectURL(file);
    } else {
      this.file = null;
      this.preview = null;
    }
  }

  handleUpdate(): void {
    const formData = new FormData();
    formData.append('roomType', this.roomDetails.roomType);
    formData.append('roomPrice', this.roomDetails.roomPrice);
    formData.append('roomDescription', this.roomDetails.roomDescription);

    if (this.file) {
      formData.append('photo', this.file);
    }

    this.apiService.updateRoom(this.roomId, formData).subscribe(
      (result: any) => {
        if (result.statusCode === 200) {
          this.success = 'Room updated successfully.';
          setTimeout(() => {
            this.success = '';
            this.router.navigate(['/admin/manage-rooms']);
          }, 3000);
        }
      },
      (error) => {
        this.error = error.error?.message || error.message;
        setTimeout(() => this.error = '', 5000);
      }
    );
  }

  handleDelete(): void {
    if (confirm('Do you want to delete this room?')) {
      this.apiService.deleteRoom(this.roomId).subscribe(
        (result: any) => {
          if (result.statusCode === 200) {
            this.success = 'Room deleted successfully.';
            setTimeout(() => {
              this.success = '';
              this.router.navigate(['/admin/manage-rooms']);
            }, 3000);
          }
        },
        (error) => {
          this.error = error.error?.message || error.message;
          setTimeout(() => this.error = '', 5000);
        }
      );
    }
  }
}
