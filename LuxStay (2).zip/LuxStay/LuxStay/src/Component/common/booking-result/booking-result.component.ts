import { Component } from '@angular/core';

@Component({
  selector: 'app-booking-result',
  standalone: true,
  imports: [],
  templateUrl: './booking-result.component.html',
  styleUrl: './booking-result.component.css'
})
export class BookingResultComponent {

}
