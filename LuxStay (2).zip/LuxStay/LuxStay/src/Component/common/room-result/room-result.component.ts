import { Component } from '@angular/core';

@Component({
  selector: 'app-room-result',
  standalone: true,
  imports: [],
  templateUrl: './room-result.component.html',
  styleUrl: './room-result.component.css'
})
export class RoomResultComponent {

}
