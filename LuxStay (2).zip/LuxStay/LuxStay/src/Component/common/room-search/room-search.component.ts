import { Component } from '@angular/core';

@Component({
  selector: 'app-room-search',
  standalone: true,
  imports: [],
  templateUrl: './room-search.component.html',
  styleUrl: './room-search.component.css'
})
export class RoomSearchComponent {

}
