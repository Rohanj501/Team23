import { Component } from '@angular/core';

@Component({
  selector: 'app-room-details-page',
  standalone: true,
  imports: [],
  templateUrl: './room-details-page.component.html',
  styleUrl: './room-details-page.component.css'
})
export class RoomDetailsPageComponent {

}
