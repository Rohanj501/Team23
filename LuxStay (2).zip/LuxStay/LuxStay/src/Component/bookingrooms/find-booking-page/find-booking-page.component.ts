import { Component } from '@angular/core';

@Component({
  selector: 'app-find-booking-page',
  standalone: true,
  imports: [],
  templateUrl: './find-booking-page.component.html',
  styleUrl: './find-booking-page.component.css'
})
export class FindBookingPageComponent {

}
