import { Component } from '@angular/core';

@Component({
  selector: 'app-navber',
  standalone: true,
  imports: [],
  templateUrl: './navber.component.html',
  styleUrl: './navber.component.css'
})
export class NavberComponent {

}
