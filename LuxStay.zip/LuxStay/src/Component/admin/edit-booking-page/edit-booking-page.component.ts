import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-booking-page',
  standalone: true,
  imports: [],
  templateUrl: './edit-booking-page.component.html',
  styleUrl: './edit-booking-page.component.css'
})
export class EditBookingPageComponent {

}
