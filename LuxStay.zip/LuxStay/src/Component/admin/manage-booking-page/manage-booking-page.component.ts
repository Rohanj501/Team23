import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-booking-page',
  standalone: true,
  imports: [],
  templateUrl: './manage-booking-page.component.html',
  styleUrl: './manage-booking-page.component.css'
})
export class ManageBookingPageComponent {

}
