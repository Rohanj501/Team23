import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllRoomsPageComponent } from './all-rooms-page.component';

describe('AllRoomsPageComponent', () => {
  let component: AllRoomsPageComponent;
  let fixture: ComponentFixture<AllRoomsPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AllRoomsPageComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AllRoomsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
