import { Component } from '@angular/core';

@Component({
  selector: 'app-all-rooms-page',
  standalone: true,
  imports: [],
  templateUrl: './all-rooms-page.component.html',
  styleUrl: './all-rooms-page.component.css'
})
export class AllRoomsPageComponent {

}
