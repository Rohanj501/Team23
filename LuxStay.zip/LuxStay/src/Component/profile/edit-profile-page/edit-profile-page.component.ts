import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-profile-page',
  standalone: true,
  imports: [],
  templateUrl: './edit-profile-page.component.html',
  styleUrl: './edit-profile-page.component.css'
})
export class EditProfilePageComponent {

}
